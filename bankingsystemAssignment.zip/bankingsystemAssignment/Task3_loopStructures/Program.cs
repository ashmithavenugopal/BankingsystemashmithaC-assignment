﻿namespace Task3_loopStructures
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the No.of Customers: ");
            int numberOfCustomers=int.Parse(Console.ReadLine());
            for(int i=0;i<=numberOfCustomers;i++)
            {
                Console.WriteLine("Enter the initial Balance: ");
                decimal initial_balance = decimal.Parse(Console.ReadLine());
                Console.WriteLine("Enter Annual interest rate: ");
                decimal annualInterestRate = decimal.Parse(Console.ReadLine());
                Console.WriteLine("Enter the No.of years: ");
                int numberOfYears = int.Parse(Console.ReadLine());
                decimal futureBalance;
                futureBalance = initial_balance * (decimal)Math.Pow ((double) (1 + annualInterestRate / 100), numberOfYears);
                Console.WriteLine($"The Future Balance will be : {futureBalance}");

            }

        }
    }
}
