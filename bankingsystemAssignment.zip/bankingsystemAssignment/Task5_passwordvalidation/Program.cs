﻿namespace Task5_passwordvalidation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Create a password for your bank account:");
            string password = Console.ReadLine();

            if (IsPasswordValid(password))
            {
                Console.WriteLine("Password is valid!");
            }
            else
            {
                Console.WriteLine("Password is not valid. Please make sure:");
                Console.WriteLine("- It is at least 8 characters long.");
                Console.WriteLine("- It contains at least one uppercase letter.");
                Console.WriteLine("- It contains at least one digit.");
            }
        }
        static bool IsPasswordValid(string password)
        {
            // Check length
            if (password.Length < 8)
                return false;

            // Check for uppercase letter
            bool hasUppercase = false;
            foreach (char c in password)
            {
                if (char.IsUpper(c))
                {
                    hasUppercase = true;
                    break;
                }
            }
            if (!hasUppercase)
                return false;

            // Check for digit
            bool hasDigit = false;
            foreach (char c in password)
            {
                if (char.IsDigit(c))
                {
                    hasDigit = true;
                    break;
                }
            }

            if (!hasDigit)
                return false;

            // If all conditions pass
            return true;
        }
    }
}
