﻿namespace Task4_LoopingArrayDatavalidation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] accountId = { "12345", "23456", "34567" };
            double[] balance = { 100000.00, 250000.00, 175000.70 };
            while (true)
            {
                Console.WriteLine("Enter your account number");
                string id =Console.ReadLine();
                int index = avail(id, accountId);
                if (index < 0)
                {
                    Console.WriteLine("No user found");
                }
                else
                {
                    Console.WriteLine($"The balance for the account id {accountId[index]} is {balance[index]}");
                }
            }
            
        }


        public static int avail(string id , string [] accountId)
        {
            for(int i = 0; i < accountId.Length; i++) 
            {
                if (accountId[i].Equals(id))
                {
                    return i;
                }
            
            }
            return -1;
        }
    }
}
