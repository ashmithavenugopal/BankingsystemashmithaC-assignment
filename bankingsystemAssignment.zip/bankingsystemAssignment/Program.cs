﻿using bankingsystemAssignment.Task9_14.service;

namespace bankingsystemAssignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankServiceProvider bankProvider = new BankServiceProvider();
            CustomerServiceProvider customerProvider = new CustomerServiceProvider();

            while (true)
            {
                Console.WriteLine("Welcome To Banking System");
                Console.WriteLine("-----------------------");

                Console.WriteLine("1. Customer Services");
                Console.WriteLine("2. Bank Services");
                Console.WriteLine("Choose a option ");
                int id = Convert.ToInt32(Console.ReadLine());
                switch (id)
                {
                    case 1:
                        customerProvider.CustomerService();
                        break;
                    case 2:
                        bankProvider.BankService();
                        break;
                }
            }
        }
    }
}
