﻿using bankingsystemAssignment.Task9_14.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingsystemAssignment.Task9_14.repository
{
    internal abstract class IBankProvider : Accounts
    {
        public abstract List<Accounts> ListAll();

        public abstract void CreateAccount(Accounts account);

        public abstract void CalculateInterest(string id);
    }
}
