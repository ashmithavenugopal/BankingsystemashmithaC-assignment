﻿using BankAssignment.Utilities;
using bankingsystemAssignment.Task9_14.Exceptions;
using bankingsystemAssignment.Task9_14.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingsystemAssignment.Task9_14.repository
{
    internal class ICustomerProviderImp : ICustomerProvider
    {
        SqlConnection sql = null;
        SqlCommand cmd = null;
        SavingsAccount savings = new SavingsAccount();
        CurrentAccount current = new CurrentAccount();
        ZeroAccount zero = new ZeroAccount();
        public ICustomerProviderImp()
        {
            sql = new SqlConnection(DbUtil.GetConnection());
            cmd = new SqlCommand();

        }

        public override void getAccountDetails(int id)
        {

            try
            {
                cmd.CommandText = "Select * from Accounts where account_id = @id";
                cmd.Connection = sql;

                sql.Open();
                cmd.Parameters.AddWithValue("@id", id);

                int accountid1 = 0;
                int customerId = 0;
                string type = "";
                double Balance = 0;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        accountid1 = (int)reader["account_id"];
                        customerId = (int)reader["customer_id"];
                        type = (string)reader["account_type"];
                        Balance = (double)((decimal)reader["balance"]);
                    }
                }

                Console.WriteLine($"Account Id : {accountid1} \t Customer Id : {customerId} \t Account Type : {type} \t Account Balance : {Balance}");
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine($"SQL Error: {sqlEx.Message}");
            }

            finally
            {
                sql.Close();
            }

        }
        public override void deposit(int id, double amount)
        {
            try
            {
                cmd.CommandText = "update Accounts set balance=balance + @amount where account_id = @id";

                cmd.Connection = sql;

                sql.Open();
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@amount", amount);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    Console.WriteLine($"Thank you for using the Bank {id}");
                }
                else
                {
                    throw new ServerIssueException("There seems to be a issue with the server");
                }
            }
            catch (SqlException sqlexp)
            {
                Console.WriteLine(sqlexp.Message);
            }
            sql.Close();
        }
        public override void withdraw(int id, double amount)
        {
            try
            {
                cmd.CommandText = "select account_type from Accounts where account_id = @id";
                cmd.Connection = sql;
                sql.Open();
                string type = "";
                cmd.Parameters.AddWithValue("@id", id);

                SqlDataReader r = cmd.ExecuteReader();

                while (r.Read())
                {
                    type = (string)r["account_type"];
                }

                if (type == "Savings")
                {
                    savings.withdraw(id, amount);
                }
                else if (type == "Current")
                {
                    current.withdraw(id, amount);

                }
                else
                {
                    zero.withdraw(id, amount);
                }
            }
            catch (SqlException sqlexp)
            {
                Console.WriteLine(sqlexp.Message);
            }
            finally
            {
                sql.Close();
            }
        }
        public override void TransferAmount(int fromacc, int toacc, double amount)
        {
            try
            {
                cmd.CommandText = "SELECT * FROM Accounts WHERE account_id = @from OR account_id = @to";
                cmd.Connection = sql;
                cmd.Parameters.AddWithValue("@from", fromacc);
                cmd.Parameters.AddWithValue("@to", toacc);

                sql.Open();

                Dictionary<int, double> accountBalances = new Dictionary<int, double>();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int accountId = (int)reader["account_id"];
                        double balance = (double)((decimal)reader["balance"]); ;
                        accountBalances.Add(accountId, balance);
                    }
                }

                if (!accountBalances.ContainsKey(fromacc))
                {
                    throw new Exception("The sender account does not exist.");
                }

                if (!accountBalances.ContainsKey(toacc))
                {
                    throw new Exception("The receiver account does not exist.");
                }
                if (accountBalances[fromacc] < amount)
                {
                    throw new Exception("The sender does not have sufficient balance to transfer.");
                }

                cmd.CommandText = "UPDATE Accounts SET balance = @frombalance WHERE account_id = @from;" +
                                  "UPDATE Accounts SET balance = @toBalance WHERE account_id = @to;";
                cmd.Parameters.Clear();

                cmd.Parameters.AddWithValue("@from", fromacc);
                cmd.Parameters.AddWithValue("@to", toacc);
                cmd.Parameters.AddWithValue("@fromBalance", accountBalances[fromacc] - amount);
                cmd.Parameters.AddWithValue("@toBalance", accountBalances[toacc] + amount);
                int rows = cmd.ExecuteNonQuery();

                Console.WriteLine($"Transfer of {amount} from account {fromacc} to account {toacc}ccessful.");

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                sql.Close();
            }
        }
        public override void GetAccountBalance(int id)
        {
            try
            {
                cmd.CommandText = "Select balance from Accounts where account_id = @id";
                cmd.Connection = sql;

                sql.Open();
                cmd.Parameters.AddWithValue("@id", id);


                double Balance = 0;

                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {

                        Balance = (double)((decimal)r["balance"]);
                    }
                }

                Console.WriteLine($"Your Account Balance is : {Balance}");
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine($"SQL Error: {sqlEx.Message}");
            }

            finally
            {
                sql.Close();
            }
        }
    }
}
