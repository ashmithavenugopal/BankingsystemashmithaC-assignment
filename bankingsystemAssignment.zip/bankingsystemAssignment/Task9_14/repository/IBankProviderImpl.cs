﻿using BankAssignment.Utilities;
using bankingsystemAssignment.Task9_14.Exceptions;
using bankingsystemAssignment.Task9_14.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingsystemAssignment.Task9_14.repository
{
    internal class IBankProviderImpl : IBankProvider
    {

        SavingsAccount savings = new SavingsAccount();
        ZeroAccount zero = new ZeroAccount();
        CurrentAccount current = new CurrentAccount();
        SqlConnection sql = null;
        SqlCommand cmd = null;

        public IBankProviderImpl()
        {
            cmd = new SqlCommand();
            sql = new SqlConnection(DbUtil.GetConnection());
        }

        public override void CalculateInterest(string id)
        {

            try
            {
                int Id = 0;
                InvalidInputException.CheckIfInteger(id, ref Id);

                try
                {
                    cmd.CommandText = "select account_type from Accounts where account_id = @id";
                    cmd.Connection = sql;
                    sql.Open();
                    string type = "";
                    cmd.Parameters.AddWithValue("@id", Id);

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        type = (string)reader["account_type"];
                    }

                    if (type == "Savings")
                    {
                        savings.calculateInterest(Id);
                    }
                    else if (type == "Current")
                    {
                        current.calculateInterest(Id);

                    }
                    else
                    {
                        zero.calculateInterest(Id);
                    }
                }
                catch (SqlException sqlexp)
                {
                    Console.WriteLine(sqlexp.Message);
                }
                finally
                {
                    sql.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        public override List<Accounts> ListAll()
        {
            List<Accounts> acc = new List<Accounts>();

            cmd.CommandText = "Select * from Accounts";
            cmd.Connection = sql;

            sql.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Accounts account = new Accounts();

                account.AccountId = (int)reader["account_id"];
                account.CustomerId = (int)reader["customer_id"];
                account.AccountType = (string)reader["account_type"];
                account.Balance = (double)((decimal)reader["balance"]);
                
                acc.Add(account);

            }
            sql.Close();


            return acc;
        }

        public override void CreateAccount(Accounts bankAccount)
        {
            cmd.CommandText = "insert into Accounts(customer_id,account_type,balance) values(@customerId,@accounttype,@balance)";
            cmd.Connection = sql;
            sql.Open();
            
            cmd.Parameters.AddWithValue("@customerId", bankAccount.CustomerId);
            cmd.Parameters.AddWithValue("@accounttype", bankAccount.AccountType);
            cmd.Parameters.AddWithValue("@balance", bankAccount.Balance);
            cmd.ExecuteNonQuery();
            cmd.CommandText = "Select account_id from Accounts where customer_id = @id and account_type = @type and balance = @b";
            cmd.Parameters.AddWithValue("@id", bankAccount.CustomerId);
            cmd.Parameters.AddWithValue("@type", bankAccount.AccountType);
            cmd.Parameters.AddWithValue("@b", bankAccount.Balance);
            SqlDataReader reader = cmd.ExecuteReader();
            int id = 0;
            while (reader.Read())
            {
                id = (int)reader["account_id"];
            }
           
            Console.WriteLine($"Your Account has been created naming {bankAccount.CustomerName} and the AccountId is {id}");
        }

       
    }
}
