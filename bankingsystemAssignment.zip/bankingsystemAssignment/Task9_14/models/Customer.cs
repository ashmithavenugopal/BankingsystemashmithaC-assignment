﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace bankingsystemAssignment.Task9_14.models
{
    internal class Customer
    {
        string customer_id;
        string first_name;
        string last_name;
        string email;
        string phone;
        string address;


        public Customer()
        {
            CustomerId = "";
            FirstName = "";
            LastName = "";
            Email = "";
            Phone = "";
            Address = "";

        }

        public Customer(string customerId, string frst, string last, string email, string phone, string address)
        {
            CustomerId = customerId;
            FirstName = frst;
            LastName = last;
            Email = email;
            Phone = phone;
            Address = address;
        }

        public string CustomerId
        {
            get { return customer_id; }
            set { customer_id = value; }
        }

        public string FirstName
        {
            get { return first_name; }
            set { first_name = value; }
        }

        public string LastName
        {
            get { return last_name; }
            set { last_name = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }


        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }


        public void printDetails()
        {
            Console.WriteLine($"The customer Id is :{CustomerId}");
            Console.WriteLine($"The Customer frst name is :{FirstName}");
            Console.WriteLine($"The Customer Last Name is :{LastName}");
            Console.WriteLine($"The cusomer email id{Email}");
            Console.WriteLine($"The customer Phone number is {Phone}");
            Console.WriteLine($"The Address of the customer is {Address}");
        }
    }
}
