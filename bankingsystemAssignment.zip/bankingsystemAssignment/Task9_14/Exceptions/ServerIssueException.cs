﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingsystemAssignment.Task9_14.Exceptions
{
    internal class ServerIssueException
    {
        public ServerIssueException(string message) : base(message) { }
    }
}
