﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task7_classesandobjects
{
    internal class Customer
    {
        public string CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }

        // Default Constructor
        public Customer()
        {
            // Initialize default values
            CustomerId = "";
            FirstName = "";
            LastName = "";
            EmailAddress = "";
            PhoneNumber = "";
            Address = "";
        }
        // Overloaded Constructor
        public Customer(string id, string fName, string lName, string email, string phone, string addr)
        {
            CustomerId = id;
            FirstName = fName;
            LastName = lName;
            EmailAddress = email;
            PhoneNumber = phone;
            Address = addr;
        }
        public void PrintCustomerInfo()
        {
            Console.WriteLine($"Customer ID: {CustomerId}");
            Console.WriteLine($"Name: {FirstName} {LastName}");
            Console.WriteLine($"Email Address: {EmailAddress}");
            Console.WriteLine($"Phone Number: {PhoneNumber}");
            Console.WriteLine($"Address: {Address}");
        }
    }
}
