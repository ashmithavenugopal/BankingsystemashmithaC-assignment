﻿using System.Security.Principal;

namespace Task7_classesandobjects
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create a customer object
            Customer customer = new Customer("C1", "Ashmitha", "V", "ash@gmail.com", "1234567890", "123 Main St");

            // Print customer information
            Console.WriteLine("Customer Information:");
            customer.PrintCustomerInfo();

            // Create an account object
            Account account = new Account("AC1", "Savings", 1000);

            // Print account information
            Console.WriteLine("\nAccount Information:");
            account.PrintAccountInfo();

            // Deposit into the account
            Bank.Deposit(account, 500);

            // Withdraw from the account
            Bank.Withdraw(account, 200);

            // Calculate interest
            Bank.CalculateInterest(account);

            // Print updated account information
            Console.WriteLine("\nUpdated Account Information:");
            account.PrintAccountInfo();
        }
    }
}
