﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task7_classesandobjects
{
    internal class Bank
    {
        public static void Deposit(Account account, float amount)
        {
            account.Deposit(amount);
        }

        // Method to withdraw from the account
        public static void Withdraw(Account account, float amount)
        {
            account.Withdraw(amount);
        }

        // Method to calculate interest for savings account
        public static void CalculateInterest(Account account)
        {
            if (account.AccountType == "Savings")
            {
                account.CalculateInterest();
            }
            else
            {
                Console.WriteLine("Interest calculation is not applicable for this account type.");
            }
        }
    }
}
