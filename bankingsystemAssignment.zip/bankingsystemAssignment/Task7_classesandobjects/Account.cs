﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task7_classesandobjects
{
    internal class Account
    {
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public float AccountBalance { get; set; }

        // Default Constructor
        public Account()
        {
            // Initialize default values
            AccountNumber = "";
            AccountType = "";
            AccountBalance = 0;
        }

        // Overloaded Constructor
        public Account(string number, string type, float balance)
        {
            AccountNumber = number;
            AccountType = type;
            AccountBalance = balance;
        }
        public void PrintAccountInfo()
        {
            Console.WriteLine($"Account Number: {AccountNumber}");
            Console.WriteLine($"Account Type: {AccountType}");
            Console.WriteLine($"Account Balance: {AccountBalance}");
        }

        // Deposit method
        public void Deposit(float amount)
        {
            AccountBalance += amount;
            Console.WriteLine($"Deposited {amount} into the account.");
        }
        public void Withdraw(float amount)
        {
            if (amount <= AccountBalance)
            {
                AccountBalance -= amount;
                Console.WriteLine($"Withdrawn {amount} from the account.");
            }
            else
            {
                Console.WriteLine("Insufficient balance.");
            }
        }
        public void CalculateInterest()
        {
            // Assuming interest rate is fixed at 4.5%
            float interest = AccountBalance * 0.045f;
            AccountBalance += interest;
            Console.WriteLine($"Interest calculated and added: {interest}");
        }
    }
}
