﻿namespace Task6_passwordValidation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> transactionHistory = new List<string>();

            Console.WriteLine("Welcome to the Bank Transaction System!");

            bool continueTransactions = true;

            while (continueTransactions)
            {
                Console.WriteLine("\nChoose an option:");
                Console.WriteLine("1. Add Deposit");
                Console.WriteLine("2. Add Withdrawal");
                Console.WriteLine("3. Exit");

                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter deposit amount: ");
                        double depositAmount;
                        if (!double.TryParse(Console.ReadLine(), out depositAmount))
                        {
                            Console.WriteLine("Invalid input. Please enter a valid amount.");
                            continue;
                        }
                        transactionHistory.Add($"Deposit: +${depositAmount}");
                        Console.WriteLine("Deposit added successfully.");
                        break;

                    case 2:
                        Console.Write("Enter withdrawal amount: ");
                        double withdrawalAmount;
                        if (!double.TryParse(Console.ReadLine(), out withdrawalAmount))
                        {
                            Console.WriteLine("Invalid input. Please enter a valid amount.");
                            continue;
                        }
                        transactionHistory.Add($"Withdrawal: -${withdrawalAmount}");
                        Console.WriteLine("Withdrawal added successfully.");
                        break;

                    case 3:
                        continueTransactions = false;
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a valid option.");
                        break;
                }
            }

            Console.WriteLine("\nTransaction History:");
            foreach (string transaction in transactionHistory)
            {
                Console.WriteLine(transaction);
            }

            Console.WriteLine("\nThank you for using the Bank Transaction System!");
        }
    }
}
