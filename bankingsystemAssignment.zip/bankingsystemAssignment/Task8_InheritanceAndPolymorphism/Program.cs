﻿using Task8_InheritanceAndPolymorphism.Models;
using Task8_InheritanceAndPolymorphism.Repository;

namespace Task8_InheritanceAndPolymorphism
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region task8_1
            //AccountRepository accountrepo = new AccountRepository();
            ////depositing and withdrawing using float values
            //accountrepo.Deposit(1000.5f);
            //accountrepo.Withdraw(500.75f);
            ////depositing and withdrawing using int values
            //accountrepo.Deposit(1000);
            //accountrepo.Withdraw(750);
            ////depositing and withdrawing using double values
            //accountrepo.Deposit(1000.50);
            //accountrepo.Withdraw(700.00);

            //Console.WriteLine($"Current Balance {accountrepo.GetBalance()}");
            #endregion

            #region task8_2
            SavingsAccountRepository savingsAccount = new SavingsAccountRepository(1, "Ash", 67000.98, 0.60);
            savingsAccount.Deposit(1000);

            CurrentAccount currentAccount = new CurrentAccount(4578.98);
            currentAccount.Deposit(900);
            currentAccount.Withdraw(600);
            currentAccount.Withdraw(790000);
            #endregion

            #region task8_3 
            AccountRepository accountrepo = null;
            double initialBalance = 0;

            Console.WriteLine("Choose account type:");
            Console.WriteLine("1. Savings Account");
            Console.WriteLine("2. Current Account");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine("Enter initial balance for Savings Account:");
                    initialBalance = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter interest rate for Savings Account:");
                    double interestRate = double.Parse(Console.ReadLine());
                    SavingsAccount savingacc = new SavingsAccount(initialBalance, interestRate);
                    break;
                case 2:
                    Console.WriteLine("Enter initial balance for Current Account:");
                    initialBalance = double.Parse(Console.ReadLine());
                    accountrepo = new CurrentAccount(initialBalance);
                    break;
                default:
                    Console.WriteLine("Invalid choice.");
                    break;
            }

            if (accountrepo != null)
            {
                Console.WriteLine("Choose operation:");
                Console.WriteLine("1. Deposit");
                Console.WriteLine("2. Withdraw");
                Console.WriteLine("3. Calculate Interest (for Savings Account)");

                int operation = int.Parse(Console.ReadLine());

                switch (operation)
                {
                    case 1:
                        Console.WriteLine("Enter deposit amount:");
                        double depositAmount = double.Parse(Console.ReadLine());
                        accountrepo.Deposit(depositAmount);
                        break;
                    case 2:
                        Console.WriteLine("Enter withdraw amount:");
                        double withdrawAmount = double.Parse(Console.ReadLine());
                        accountrepo.Withdraw(withdrawAmount);
                        break;
                    case 3:
                        SavingsAccount savingacc = new SavingsAccount(73468, 0.07);


                        break;
                    default:
                        Console.WriteLine("Invalid operation.");
                        break;
                }

                Console.WriteLine("Current balance: " + accountrepo.GetBalance());
            }
            #endregion

        }
            

    }
  
}
