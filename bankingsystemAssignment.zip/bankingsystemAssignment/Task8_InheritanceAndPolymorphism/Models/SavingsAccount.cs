﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task8_InheritanceAndPolymorphism.Repository;

namespace Task8_InheritanceAndPolymorphism.Models
{
    public class SavingsAccount : Account
    {
        public float interestRate = 0.06f;
        private double initialBalance;
        private double interestRate1;

        #region task 8 question 2

        public SavingsAccount(float interestRate)
        {
            
        }

        public SavingsAccount(double initialBalance, double interestRate1)
        {
            this.initialBalance = initialBalance;
            this.interestRate1 = interestRate1;
        }

        public override void calculateInterest()
        {
            Console.WriteLine($"Your amount with interest is: {initialBalance * interestRate1} ");
        }

        #endregion
    }
}
