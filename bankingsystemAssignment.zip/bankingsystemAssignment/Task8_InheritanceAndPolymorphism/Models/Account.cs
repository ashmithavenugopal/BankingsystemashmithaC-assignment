﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task8_InheritanceAndPolymorphism.Models
{
    public class Account
    {
        public static List<Account> bankAccounts = new List<Account>();
        public long AccountNumber{ get; set; }
        public string AccountType{ get; set; }
        public float Balance{ get; set; }

        public Account()
        {
            // Initialize default values
            AccountNumber = 0 ;
            AccountType = "";
            Balance = 0;
        }

        // Overloaded Constructor
        public Account(long number, string type, float balance)
        {
            AccountNumber = number;
            AccountType = type;
            Balance = balance;
        }

        public override string ToString()
        {
            return $"Account Number: {AccountNumber}\tAccount Type:{AccountType}\tBalance:{Balance}\t";
        }

        public virtual void calculateInterest()
        {
            
        }

    }
}
