﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task8_InheritanceAndPolymorphism.Repository;

namespace Task8_InheritanceAndPolymorphism.Models
{
    public class CurrentAccount:AccountRepository
    {
        public double overdraftLimit = -500;
        private double initialBalance;

        public CurrentAccount(double initialBalance)
        {
            this.initialBalance = initialBalance;
        }

        #region task8_2

        public double balance;
        public override void Withdraw(double amount)
        {
            if (balance - amount < overdraftLimit)
            {
                Console.WriteLine("Overdraft Limit exceeded");
            }
            else
            {
                {
                    balance -= amount;
                    Console.WriteLine($"{amount} withdrawn successful.");
                }
            }
        }
        #endregion
    }
}
