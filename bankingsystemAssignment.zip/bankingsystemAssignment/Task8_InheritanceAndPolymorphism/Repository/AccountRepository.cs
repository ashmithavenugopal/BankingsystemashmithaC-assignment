﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task8_InheritanceAndPolymorphism.Repository
{
    public class AccountRepository
    {
       public double balance;
        #region Task8_1
        //public void Deposit(float amount)
        //{
        //    balance += amount;
        //    Console.WriteLine($"The deposited amount {amount} is successful.New balance:{balance} ");
        //}
        //public void Withdraw(float amount)
        //{
        //    if (balance >= amount)
        //    {
        //        balance -= amount;
        //        Console.WriteLine($"The amount {amount} is withdrawn.New balance {balance}");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Insufficient account balance");
        //    }
        //}
        //public void Deposit(int amount)
        //{
        //    balance += amount;
        //    Console.WriteLine($"The deposited amount {amount} is successful.New balance:{balance} ");
        //}
        //public void Withdraw(int amount)
        //{
        //    if (balance >= amount)
        //    {
        //        balance -= amount;
        //        Console.WriteLine($"The amount {amount} is withdrawn.New balance {balance}");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Insufficient account balance");
        //    }
        //}
        //public virtual void Deposit(double amount)
        //{
        //    balance += amount;
        //    Console.WriteLine($"The deposited amount {amount} is successful.New balance:{balance} ");
        //}
        //public virtual void Withdraw(double amount)
        //{
        //    if (balance >= amount)
        //    {
        //        balance -= amount;
        //        Console.WriteLine($"The amount {amount} is withdrawn.New balance {balance}");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Insufficient account balance");
        //    }
        //}
        //public double getBalance()
        //{
        //    return balance;
        //}
        #endregion
        #region task8_2
        public virtual void Deposit(double amount)
        {
            balance += amount;
            Console.WriteLine($"{amount} deposited successfully.");
        }
        public virtual void Withdraw(double amount)
        {
            if (balance >= amount)
            {
                balance -= amount;
                Console.WriteLine($"{amount} withdrawn successfully.");
            }
            else
            {
                Console.WriteLine("Insufficient Balance");
            }
        }
        public virtual double CalculateInterest()

        { 
            return 0;
        }
        public double GetBalance()
        {
            return balance;
        }
#endregion
    }
}
